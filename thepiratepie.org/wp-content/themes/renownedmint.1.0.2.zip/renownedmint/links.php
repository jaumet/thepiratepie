<?php get_header(); ?>
	<div id="content_wrapper">
		<div id="content">
			<h2>Links:</h2>
			<ul>
				<?php wp_list_bookmarks(); ?>
			</ul>
		</div>
	</div>
<?php get_footer(); ?>
