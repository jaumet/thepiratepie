<?php get_header(); ?>
	<div id="content_wrapper">
		<div id="content">
			<h1>Error 404 - Not Found</h2>
		</div>
	</div>
<?php get_footer(); ?>