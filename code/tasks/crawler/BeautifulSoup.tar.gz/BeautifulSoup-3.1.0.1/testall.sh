#!/bin/sh
python BeautifulSoupTests.py && sh to3.sh && cd python3 && python3 BeautifulSoupTests.py
